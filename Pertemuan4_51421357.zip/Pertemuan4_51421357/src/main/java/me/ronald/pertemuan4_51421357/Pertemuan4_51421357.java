/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package me.ronald.pertemuan4_51421357;

/**
 *
 * @author totos
 */
public class Pertemuan4_51421357 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
