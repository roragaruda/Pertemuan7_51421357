/*
*
To change this license header, choose License Headers in Project Properties.
*
To change this template file, choose Tools | Templates
*
and open the template in the editor.
 */
package com.mycompany.pertemuan2_51421357.Pertemuan2_51421357;

public class Pertemuan2_51421357 {

    public static void main(String[] args) {
        Mahasiswa mahasiswa = new Mahasiswa("Aji", "51421449", 21);
        mahasiswa.tampilkanData();
        System.out.println();

        MahasiswaSarjana mahasiswaSarjana = new MahasiswaSarjana("Adrian", "1233465", 22, "Informatika");
        mahasiswaSarjana.tampilkanData();
        System.out.println();
    }
}