/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package me.ronald.mahasiswa.pert3_51421357;

/**
 *
 * @author totos
 */
public class Pert3_51421357 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
